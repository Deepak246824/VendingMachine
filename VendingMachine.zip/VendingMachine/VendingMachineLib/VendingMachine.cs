﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace VendingMachineLib
{
    public class VendingMachine
    {

        public List<double> GetValidCoins(List<double> coinsEntered)
        {
            List<double>  validCoins = coinsEntered.Where(i => (i == 0.1) || (i == 0.25) || (i == 0.5)).ToList();

            return validCoins;

        }


        public List<double> GetInValidCoins(List<double> coinsEntered)
        {
            List<double>  invalidCoins = coinsEntered.Where(i => (i != 0.1) && (i != 0.25) && (i != 0.5)).ToList();

            return invalidCoins;

        }

        public string GetItem(List<double> validCoins,string item)
        {
            string message = string.Empty;
            double totalAmount= validCoins.Sum();

            switch(item)
            {
                case "cola":
                    if(totalAmount>=1)
                    {
                        message = "Thank You";
                    }
                    else
                    {
                        message = "INSERT COIN or the current amount as appropriate";
                    }
                    break;

                case "chips":
                    if (totalAmount >= 0.5)
                    {
                        message = "Thank You";
                    }
                    else
                    {
                        message = "INSERT COIN or the current amount as appropriate";
                    }
                    break;

                case "candy":
                    if (totalAmount >= 0.65)
                    {
                        message = "Thank You";
                    }
                    else
                    {
                        message = "INSERT COIN or the current amount as appropriate";
                    }
                    break;

                default:
                    message= "Invalid Selection";
                    break;

            }

            return message;
        }
    }
}

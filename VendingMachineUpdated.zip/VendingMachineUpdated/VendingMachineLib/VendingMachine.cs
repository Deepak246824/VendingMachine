﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace VendingMachineLib
{
    public class VendingMachine
    {

        public List<double> GetValidCoins(List<double> coinsEntered)
        {
            List<double>  validCoins = coinsEntered.Where(i => (i == 0.1) || (i == 0.25) || (i == 0.5)).ToList();

            return validCoins;

        }


        public List<double> GetInValidCoins(List<double> coinsEntered)
        {
            List<double>  invalidCoins = coinsEntered.Where(i => (i != 0.1) && (i != 0.25) && (i != 0.5)).ToList();

            return invalidCoins;

        }

        public string GetItem(List<double> validCoins,string item)
        {
            string message = string.Empty;
            double totalAmount= validCoins.Sum();
            double remainingAmount = 0;
            List<double> remainingCoins = new List<double>();

            switch(item)
            {
                case "cola":
                    if(totalAmount>=1)
                    {
                        remainingAmount = totalAmount - 1;
                        remainingCoins = GetRemainingCoins(validCoins,1);

                        message = remainingAmount>0? string.Format($"Thank You and please collect the remaining amount - {remainingAmount.ToString()} remaining coins - {string.Join(',', remainingCoins)}") : "Thank You";

                    }
                    else
                    {
                        message = "INSERT COIN or the current amount as appropriate";
                    }
                    break;

                case "chips":
                    if (totalAmount >= 0.5)
                    {
                        remainingAmount = totalAmount - 0.5;
                        remainingCoins = GetRemainingCoins(validCoins, 0.5);

                        message = remainingAmount > 0 ? string.Format($"Thank You and please collect the remaining amount - {remainingAmount.ToString()} remaining coins - {string.Join(',', remainingCoins)}") : "Thank You";
                    }
                    else
                    {
                        message = "INSERT COIN or the current amount as appropriate";
                    }
                    break;

                case "candy":
                    if (totalAmount >= 0.65)
                    {
                        remainingAmount = totalAmount - 0.65;
                        remainingCoins = GetRemainingCoins(validCoins, 0.65);

                        message = remainingAmount > 0 ? string.Format($"Thank You and please collect the remaining amount - {remainingAmount.ToString()} remaining coins - {string.Join(',', remainingCoins)}") : "Thank You";
                    }
                    else
                    {
                        message = "INSERT COIN or the current amount as appropriate";
                    }
                    break;

                default:
                    message= "Invalid Selection";
                    break;

            }

            return message;
        }

        public List<double> GetRemainingCoins(List<double> validCoins,double itemPrice)
        {
            double buyAmount = 0;
            int currentIndex = 0;
            List<double> remainingCoins = new List<double>();

            for (int i = 0; i < validCoins.Count; i++)
            {
                buyAmount = buyAmount + validCoins[i];
                if (buyAmount >= itemPrice)
                {
                    currentIndex = i;
                    break;
                }
            }

            for (int i = currentIndex+1; i < validCoins.Count; i++)
            {
                remainingCoins.Add(validCoins[i]);
            }

            return remainingCoins;

        }
    }
}

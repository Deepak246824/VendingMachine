﻿using System;
using System.Collections.Generic;
using VendingMachineLib;

namespace VendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            List<double> coinsEntered = new List<double>() { 0.5,0.5,0.25,0.1,0.8};

            VendingMachineLib.VendingMachine vendingMachine = new VendingMachineLib.VendingMachine();

            List<double> invalidCoins= vendingMachine.GetInValidCoins(coinsEntered);
            List<double> validCoins= vendingMachine.GetValidCoins(coinsEntered);

            string message= vendingMachine.GetItem(validCoins,"cola");

            Console.WriteLine(message);
        }
    }
}

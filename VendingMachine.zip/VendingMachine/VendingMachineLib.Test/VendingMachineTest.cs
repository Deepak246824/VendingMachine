using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace VendingMachineLib.Test
{
    [TestClass]
    public class VendingMachineTest
    {
        VendingMachine vendingMachine;
        public VendingMachineTest()
        {
            vendingMachine = new VendingMachineLib.VendingMachine();
        }

        [TestMethod]
        public void GetValidCoins_Test()
        {
            List<double> coinsEntered = new List<double>() { 0.5, 0.5, 0.25, 0.1, 0.8 };

            int count=vendingMachine.GetValidCoins(coinsEntered).Count;

            Assert.AreEqual(4,count);
        }

        [TestMethod]
        public void GetInValidCoins_Test()
        {
            List<double> coinsEntered = new List<double>() { 0.5, 0.5, 0.25, 0.1, 0.8 };

            int count = vendingMachine.GetInValidCoins(coinsEntered).Count;

            Assert.AreEqual(1, count);
        }

        [TestMethod]
        public void GetItem_Cola_Valid_Test()
        {
            List<double> validCoins = new List<double>() { 0.5, 0.5, 0.25, 0.1};

            string message = vendingMachine.GetItem(validCoins,"cola");
            Assert.AreEqual("Thank You", message);
        }

        [TestMethod]
        public void GetItem_Cola_InValid_Test()
        {
            List<double> validCoins = new List<double>() { 0.25, 0.1 };

            string message = vendingMachine.GetItem(validCoins, "cola");
            Assert.AreEqual("INSERT COIN or the current amount as appropriate", message);
        }


        [TestMethod]
        public void GetItem_Chips_Valid_Test()
        {
            List<double> validCoins = new List<double>() { 0.5};

            string message = vendingMachine.GetItem(validCoins, "chips");
            Assert.AreEqual("Thank You", message);
        }

        [TestMethod]
        public void GetItem_Chips_InValid_Test()
        {
            List<double> validCoins = new List<double>() { 0.25, 0.1 };

            string message = vendingMachine.GetItem(validCoins, "chips");
            Assert.AreEqual("INSERT COIN or the current amount as appropriate", message);
        }

        [TestMethod]
        public void GetItem_Candy_Valid_Test()
        {
            List<double> validCoins = new List<double>() { 0.5,0.5 };

            string message = vendingMachine.GetItem(validCoins, "candy");
            Assert.AreEqual("Thank You", message);
        }

        [TestMethod]
        public void GetItem_Candy_InValid_Test()
        {
            List<double> validCoins = new List<double>() { 0.25, 0.1 };

            string message = vendingMachine.GetItem(validCoins, "candy");
            Assert.AreEqual("INSERT COIN or the current amount as appropriate", message);
        }

        [TestMethod]
        public void GetItem_InValid_Test()
        {
            List<double> validCoins = new List<double>() { 0.25, 0.1 };

            string message = vendingMachine.GetItem(validCoins, "abc");
            Assert.AreEqual("Invalid Selection", message);
        }
    }
}
